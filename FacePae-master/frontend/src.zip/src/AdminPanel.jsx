import Sidebar from "./components/sidebar";

function AdminPanel() {
    return ( 
        <>
            <div className="admin-panel">
                <Sidebar />
            </div>
        </>
    );
}

export default AdminPanel;